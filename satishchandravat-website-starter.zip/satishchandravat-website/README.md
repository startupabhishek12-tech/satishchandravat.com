# Satish Chandravat — Personal Website

A responsive English-language personal website starter built with HTML, CSS and JavaScript. No build tools are required.

## Before publishing
- Replace the starter biography with accurate personal details.
- Replace the sample article cards with real articles and links. They are placeholders.
- Replace `hello@example.com` in `index.html` with a public contact email.
- Add your own links, photos, publications and project details.
- Only publish content and photos you have permission to share.

## Preview locally
Open `index.html` in a browser. Or run `python -m http.server 8000` from this folder and open `http://localhost:8000`.

## Publish using GitHub Pages
1. Sign in or create an account at https://github.com.
2. Create a repository (for example, `satishchandravat-website`).
3. Upload the files from this folder to the repository root.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
6. After deployment, GitHub will display a public `github.io` address.

## Connect satishchandravat.com
You must register/own the domain separately; this starter does not register it.
1. In **Settings → Pages**, enter `satishchandravat.com` under **Custom domain** and save.
2. At the domain registrar, configure DNS using GitHub's current instructions. Follow their exact current A/AAAA and CNAME values.
3. After DNS is ready, enable HTTPS in GitHub Pages.

Official instructions: https://docs.github.com/en/pages
Custom domains: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

## Limitations
This is a static site: there is no server-side contact form or admin dashboard. The email button opens the visitor's email application. A CMS can be added later.
